WorkLog Extensions.zip 을 chrome://extensions/ 에서 해당 파일을 업로드하여 마음껏 사용하세요. 
